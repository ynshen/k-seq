
allowed_units = ['g', 'mg', 'ug', 'ng',
                 'mol', 'mmol', 'umol', 'fmol']