"""This module contains the submodule needed for estimator
"""


class EstimatorType:

    def __init__(self):
        pass
