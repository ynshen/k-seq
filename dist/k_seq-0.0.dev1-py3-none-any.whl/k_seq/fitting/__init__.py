"""This module contains the submodule needed for fitting
"""